import {Injectable} from '@angular/core';

@Injectable()
export class StyleManagerService {
  constructor() {
  }

  /**
   * Set the stylesheet with the specified key.
   */
  // tslint:disable-next-line:typedef
  setStyle(key: string, href: string) {
    getLinkElementForKey(key).setAttribute('href', href);
  }

  /**
   * Remove the stylesheet with the specified key.
   */
  // tslint:disable-next-line:typedef
  removeStyle(key: string) {
    const existingLinkElement = getExistingLinkElementByKey(key);
    if (existingLinkElement) {
      document.head.removeChild(existingLinkElement);
    }
  }
}

// tslint:disable-next-line:typedef
function getLinkElementForKey(key: string) {
  return getExistingLinkElementByKey(key) || createLinkElementWithKey(key);
}

// tslint:disable-next-line:typedef
function getExistingLinkElementByKey(key: string) {
  return document.head.querySelector(
    `link[rel="stylesheet"].${getClassNameForKey(key)}`
  );
}

// tslint:disable-next-line:typedef
function createLinkElementWithKey(key: string) {
  const linkEl = document.createElement('link');
  linkEl.setAttribute('rel', 'stylesheet');
  linkEl.classList.add(getClassNameForKey(key));
  document.head.appendChild(linkEl);
  return linkEl;
}

// tslint:disable-next-line:typedef
function getClassNameForKey(key: string) {
  return `app-${key}`;
}
